#!/usr/bin/env python3
"""
build.py - local build script for clang-tools static binaries.

This script mirrors the steps in .github/workflows/build.yml so that a build
can be reproduced on any supported platform without needing GitHub Actions.

Supported platforms
-------------------
  linux-amd64    - Linux x86-64   (requires gcc-10, cmake, ninja/make)
  linux-arm64    - Linux ARM64    (requires gcc-10, cmake, ninja/make)
  macos-amd64    - macOS x86-64   (requires brew, gcc@14, cmake)
  macos-arm64    - macOS ARM64    (requires brew, gcc@14, cmake)
  windows-amd64  - Windows x86-64 (requires Visual Studio with C++ tools, cmake)
  windows-arm64  - Windows ARM64  (requires Visual Studio with C++ tools, cmake)

Usage
-----
  python build.py --version 18
  python build.py --version 17 --platform macos-arm64
  python build.py --version 20 --platform linux-amd64 --build-dir /tmp/llvm-build
  python build.py --help
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import tarfile
import urllib.request
from pathlib import Path
from typing import Any, Literal


# ---------------------------------------------------------------------------
# Version -> source release mapping (loaded from releases.json)
# ---------------------------------------------------------------------------
def _load_releases() -> dict[str, str]:
    """Load the version-to-tarball mapping from releases.json."""
    releases_path = Path(__file__).parent / "releases.json"
    with open(releases_path) as f:
        return json.load(f)


RELEASES: dict[str, str] = _load_releases()

TOOLS = [
    "clang-format",
    "clang-query",
    "clang-tidy",
    "clang-apply-replacements",
    "clang-include-cleaner",  # available starting LLVM 18
    "llvm-cov",
    "llvm-profdata",
    "llvm-symbolizer",
    "clang-scan-deps",
]

# Minimum LLVM major version for tools that were introduced after LLVM 11.
INCLUDE_CLEANER_MIN_VERSION = 18
CLANG_SCAN_DEPS_MIN_VERSION = 12


def active_tools(version: str) -> list[str]:
    """Return the list of tools that are buildable for *version*.

    clang-include-cleaner was introduced as a standalone tool in LLVM 18.
    Earlier versions only had it as a library, not a build target.

    clang-scan-deps became available as a standalone tool in LLVM 12.
    Earlier versions (11) only had it as an experimental library.
    """
    tools = list(TOOLS)
    major = int(version.split(".")[0])
    if major < INCLUDE_CLEANER_MIN_VERSION:
        tools.remove("clang-include-cleaner")
    if major < CLANG_SCAN_DEPS_MIN_VERSION:
        tools.remove("clang-scan-deps")
    return tools


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def run(cmd: list[str], **kwargs: Any) -> None:
    """Run a command, raising CalledProcessError on failure."""
    print(f"\n>>> {' '.join(str(c) for c in cmd)}", flush=True)
    subprocess.run(cmd, check=True, **kwargs)


def detect_os() -> str:
    """Return the platform key matching build.yml matrix names."""
    system_name = platform.system().lower()

    match system_name:
        case "linux" | "windows":
            return system_name

        case "darwin":
            return "macos"

        case _:
            raise RuntimeError(f"Unsupported operating system: {system_name!r}")


def detect_arch() -> Literal["amd64", "arm64"]:
    """Return the architecture string used in binary suffixes."""
    machine_type = platform.machine().lower()
    return "arm64" if machine_type in ("arm64", "aarch64") else "amd64"


def sha512_file(path: Path) -> str:
    """Return the hex sha512 digest of *path*."""
    h = hashlib.sha512()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download_file(url: str, dest: Path) -> None:
    """Download *url* to *dest*."""
    if dest.exists():
        print(f"[skip] {dest.name} already downloaded.")
        return
    print(f"Downloading {url} ...", flush=True)
    tmp = dest.with_suffix(".tmp")
    try:
        urllib.request.urlretrieve(url, tmp)
        tmp.rename(dest)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def unpack_tarball(tarball: Path, release: str, extra_excludes: list[str]) -> None:
    """Extract *tarball*, skipping paths listed in *extra_excludes*."""
    release_dir = Path(release)
    if release_dir.exists():
        print(f"[skip] {release} already unpacked.")
        return
    print(f"Unpacking {tarball.name} ...", flush=True)
    # Build a set of path prefixes to skip
    excludes = set(extra_excludes)

    with tarfile.open(tarball, "r:xz") as tf:
        members = []
        for member in tf.getmembers():
            skip = any(member.name.startswith(excl.rstrip("*")) for excl in excludes)
            if not skip:
                members.append(member)
        tf.extractall(path=".", members=members)


def patch_cmake_implicit_link_macos() -> None:
    """Patch brew's CMakeParseImplicitLinkInfo.cmake to recognise gcc_ext."""
    try:
        brew_prefix = subprocess.check_output(["brew", "--prefix"], text=True).strip()
    except FileNotFoundError:
        print("[warn] brew not found; skipping cmake implicit-link-library patch.")
        return

    cmake_files = list(Path(brew_prefix).rglob("CMakeParseImplicitLinkInfo.cmake"))
    if not cmake_files:
        print("[warn] CMakeParseImplicitLinkInfo.cmake not found under brew prefix.")
        return

    for cmake_file in cmake_files:
        content = cmake_file.read_text()
        patched = content.replace("gcc_eh.*|", "gcc_eh.*|gcc_ext.*|")
        if patched != content:
            print(f"Patching {cmake_file}")
            cmake_file.write_text(patched)
        else:
            print(f"[skip] {cmake_file} already patched or pattern not found.")


def apply_patch(patch_file: Path, target_dir: Path) -> None:
    """Apply a unified diff patch inside *target_dir*."""
    run(["patch", "-p1", "-d", str(target_dir), "-i", str(patch_file.resolve())])


def print_dependencies(release: str) -> None:
    """Print dynamic library dependencies of clang-format (macOS only)."""
    clang_format = Path(release) / "build" / "bin" / "clang-format"
    if clang_format.exists():
        run(["otool", "-L", str(clang_format)])
    else:
        print(f"[warn] {clang_format} not found; skipping dependency listing.")


# ---------------------------------------------------------------------------
# Platform-specific cmake argument builders
# ---------------------------------------------------------------------------


def cmake_args_linux_amd64() -> list[str]:
    return [
        "-DBUILD_SHARED_LIBS=OFF",
        "-DLLVM_ENABLE_PROJECTS=clang;clang-tools-extra",
        "-DLLVM_BUILD_STATIC=ON",
        "-DCMAKE_BUILD_TYPE=MinSizeRel",
        "-DCMAKE_CXX_FLAGS=-s -flto",
        "-DCMAKE_CXX_COMPILER=g++-10",
        "-DCMAKE_C_COMPILER=gcc-10",
    ]


def cmake_args_linux_arm64() -> list[str]:
    return [
        "-DBUILD_SHARED_LIBS=OFF",
        "-DLLVM_ENABLE_PROJECTS=clang;clang-tools-extra",
        "-DLLVM_BUILD_STATIC=ON",
        "-DCMAKE_BUILD_TYPE=MinSizeRel",
        "-DCMAKE_CXX_FLAGS=-s -flto",
        "-DCMAKE_CXX_COMPILER=g++-10",
        "-DCMAKE_C_COMPILER=gcc-10",
    ]


def cmake_args_macos_amd64() -> list[str]:
    return [
        "-DBUILD_SHARED_LIBS=OFF",
        "-DLLVM_ENABLE_PROJECTS=clang;clang-tools-extra",
        "-DCMAKE_BUILD_TYPE=MinSizeRel",
        "-DCMAKE_CXX_FLAGS=-static-libgcc -static-libstdc++ -flto -ffunction-sections -fdata-sections",
        "-DCMAKE_EXE_LINKER_FLAGS=-Wl,-dead_strip",
        "-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0",
        "-DCMAKE_CXX_COMPILER=g++-14",
        "-DCMAKE_C_COMPILER=gcc-14",
        "-DLLVM_TARGETS_TO_BUILD=X86",
        "-DLLVM_ENABLE_ZSTD=OFF",
        "-DLLVM_ENABLE_ZLIB=OFF",
        "-DCMAKE_POLICY_VERSION_MINIMUM=3.5",
    ]


def cmake_args_macos_arm64() -> list[str]:
    return [
        "-DBUILD_SHARED_LIBS=OFF",
        "-DLLVM_ENABLE_PROJECTS=clang;clang-tools-extra",
        "-DCMAKE_BUILD_TYPE=MinSizeRel",
        "-DCMAKE_CXX_FLAGS=-static-libgcc -static-libstdc++ -flto -ffunction-sections -fdata-sections",
        "-DCMAKE_EXE_LINKER_FLAGS=-Wl,-dead_strip",
        "-DCMAKE_OSX_DEPLOYMENT_TARGET=11.0",
        "-DCMAKE_CXX_COMPILER=g++-14",
        "-DCMAKE_C_COMPILER=gcc-14",
        "-DLLVM_TARGETS_TO_BUILD=AArch64",
        "-DLLVM_ENABLE_ZSTD=OFF",
        "-DCMAKE_POLICY_VERSION_MINIMUM=3.5",
    ]


def cmake_args_windows_amd64() -> list[str]:
    return [
        "-DBUILD_SHARED_LIBS=OFF",
        "-DLLVM_ENABLE_PROJECTS=clang;clang-tools-extra",
        "-Thost=x64",
        "-DCMAKE_CXX_FLAGS=/MP /std:c++14",
        "-DLLVM_USE_CRT_MINSIZEREL=MT",
    ]


def cmake_args_windows_arm64() -> list[str]:
    return [
        "-DBUILD_SHARED_LIBS=OFF",
        "-DLLVM_ENABLE_PROJECTS=clang;clang-tools-extra",
        "-Thost=ARM64",
        "-DCMAKE_CXX_FLAGS=/MP /std:c++14",
        # Building every LLVM backend runs the windows-11-arm runner out of
        # memory; the tools only need the native one (as on macOS).
        "-DLLVM_TARGETS_TO_BUILD=AArch64",
        "-DLLVM_USE_CRT_MINSIZEREL=MT",
    ]


CMAKE_ARGS_BY_OS = {
    "linux-amd64": cmake_args_linux_amd64,
    "linux-arm64": cmake_args_linux_arm64,
    "macos-amd64": cmake_args_macos_amd64,
    "macos-arm64": cmake_args_macos_arm64,
    "windows-amd64": cmake_args_windows_amd64,
    "windows-arm64": cmake_args_windows_arm64,
}


def build_args_by_os(is_windows: bool) -> list[str]:
    if is_windows:
        return ["--config", "MinSizeRel"]

    cpu_count = os.cpu_count() or 1
    return [f"-j{cpu_count}"]


def bin_dir(release: str, is_windows: bool) -> Path:
    sub = "MinSizeRel/bin" if is_windows else "bin"
    return Path(release) / "build" / sub


# ---------------------------------------------------------------------------
# Main build logic
# ---------------------------------------------------------------------------


def build(version: str, target_platform: str, script_dir: Path) -> None:
    is_macos = target_platform.startswith("macos")
    is_windows = target_platform.startswith("windows")
    is_arm = target_platform.endswith("arm64")

    release = RELEASES[version]
    suffix = f"{version}_{target_platform}"
    dot_exe = ".exe" if is_windows else ""

    print(f"\n{'=' * 60}")
    print(f"Building clang-tools {version} for {target_platform}")
    print(f"  release : {release}")
    print(f"  suffix  : {suffix}")
    print(f"{'=' * 60}\n")

    # ------------------------------------------------------------------
    # 1. Download source tarball
    # ------------------------------------------------------------------
    tarball = Path(f"{release}.tar.xz")
    ver_tag = release[len("llvm-project-") : -len(".src")]
    url = (
        f"https://github.com/llvm/llvm-project/releases/download/"
        f"llvmorg-{ver_tag}/{release}.tar.xz"
    )
    download_file(url, tarball)

    # ------------------------------------------------------------------
    # 2. Unpack
    # ------------------------------------------------------------------
    extra_excludes: list[str] = []
    if is_windows:
        extra_excludes = [
            f"{release}/clang/test/Driver/Inputs/",
            f"{release}/libcxx/test/std/input.output/filesystems/Inputs/static_test_env/",
            f"{release}/libclc/amdgcn-mesa3d",
        ]
    unpack_tarball(tarball, release, extra_excludes)

    # ------------------------------------------------------------------
    # 3. Platform-specific patches
    # ------------------------------------------------------------------
    if is_macos:
        patch_cmake_implicit_link_macos()

    if is_arm and version == "17":
        patch_path = script_dir / "arm_streaming_fix.patch"
        if patch_path.exists():
            apply_patch(patch_path, Path(release))
        else:
            print(
                f"[warn] Patch not found at {patch_path}; skipping ARM streaming fix."
            )

    # ------------------------------------------------------------------
    # 4. CMake configure
    # ------------------------------------------------------------------
    source_dir = Path(release) / "llvm"
    build_dir = Path(release) / "build"
    build_dir.mkdir(parents=True, exist_ok=True)

    cmake_cmd = [
        "cmake",
        "-S",
        str(source_dir),
        "-B",
        str(build_dir),
    ] + CMAKE_ARGS_BY_OS[target_platform]()

    run(cmake_cmd)

    # ------------------------------------------------------------------
    # 5. Build
    # ------------------------------------------------------------------
    tools = active_tools(version)
    build_cmd = (
        [
            "cmake",
            "--build",
            str(build_dir),
        ]
        + build_args_by_os(is_windows)
        + ["--target"]
        + tools
    )
    run(build_cmd)

    # ------------------------------------------------------------------
    # 5b. Print dynamic library dependencies (macOS only)
    # ------------------------------------------------------------------
    if is_macos:
        print_dependencies(release)

    # ------------------------------------------------------------------
    # 6. Smoke test
    # ------------------------------------------------------------------
    bins = bin_dir(release, is_windows)

    # Basic --version smoke test for every built tool.
    # Note: llvm-profdata on LLVM < 17 uses a subcommand interface and
    # does NOT support --version. See llvm-profdata.cpp main() — LLVM 17
    # added explicit `if (strcmp(argv[1], "--version") == 0)` handling.
    # Older versions only recognise subcommands (merge/show/overlap) and
    # --help. We verify the binary is executable by running it with no
    # args and checking for the expected usage output.
    llvm_major = int(version.split(".")[0])
    for tool in tools:
        exe = bins / f"{tool}{dot_exe}"
        print(f"\nSmoke-testing {exe} ...")
        if tool == "llvm-profdata" and llvm_major < 17:
            result = subprocess.run(
                [str(exe)],
                capture_output=True,
                text=True,
                check=False,
            )
            if "USAGE" not in result.stdout and "USAGE" not in result.stderr:
                raise RuntimeError(
                    f"{exe.name} did not produce expected usage output:\n"
                    f"  stdout: {result.stdout.strip() or '(empty)'}\n"
                    f"  stderr: {result.stderr.strip() or '(empty)'}"
                )
            print("  Binary OK (subcommand interface)")
            continue
        run([str(exe), "--version"])

    # ------------------------------------------------------------------
    # 7. Rename binaries
    # ------------------------------------------------------------------
    for tool in tools:
        src = bins / f"{tool}{dot_exe}"
        dst = bins / f"{tool}-{suffix}{dot_exe}"
        print(f"Renaming {src.name} -> {dst.name}")
        src.rename(dst)

    # ------------------------------------------------------------------
    # 8. Generate SHA512SUMS (single file with all checksums)
    # ------------------------------------------------------------------
    sha512sums_path = bins / "SHA512SUMS"
    with open(sha512sums_path, "w") as sha_file:
        for tool in tools:
            binary = bins / f"{tool}-{suffix}{dot_exe}"
            digest = sha512_file(binary)
            sha_file.write(f"{digest}  {binary.name}\n")
            print(f"{digest}  {binary.name}")
    print(f"Checksums written to {sha512sums_path.name}")

    print(f"\nBuild complete. Artifacts are in: {bins.resolve()}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build clang-tools static binaries locally.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--version",
        "-v",
        required=True,
        choices=sorted(RELEASES),
        metavar="VERSION",
        help=(
            "Clang version to build. "
            f"Supported: {', '.join(sorted(RELEASES, key=lambda x: float(x) if '.' not in x or x.count('.') == 1 else float(x.rsplit('.', 1)[0])))}"
        ),
    )
    parser.add_argument(
        "--platform",
        "-p",
        choices=[
            "linux-amd64",
            "linux-arm64",
            "macos-amd64",
            "macos-arm64",
            "windows-amd64",
            "windows-arm64",
        ],
        default=None,
        help=(
            "Target platform. Defaults to auto-detected host platform. "
            "linux-amd64=Linux x86-64, linux-arm64=Linux ARM64, "
            "macos-amd64=macOS x86-64, macos-arm64=macOS ARM64, "
            "windows-amd64=Windows x86-64, "
            "windows-arm64=Windows ARM64."
        ),
    )
    parser.add_argument(
        "--build-dir",
        "-b",
        default=None,
        metavar="DIR",
        help="Working directory for downloads and build artifacts (default: current directory).",
    )

    arguments = parser.parse_args()
    target_platform = arguments.platform or f"{detect_os()}-{detect_arch()}"
    script_dir = Path(__file__).parent.resolve()

    if arguments.build_dir:
        build_path = Path(arguments.build_dir)
        build_path.mkdir(parents=True, exist_ok=True)
        os.chdir(build_path)

    try:
        build(arguments.version, target_platform, script_dir)
    except subprocess.CalledProcessError as exc:
        print(f"\nBuild failed (exit code {exc.returncode}).", file=sys.stderr)
        sys.exit(exc.returncode)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
